# ***uisdata*** library
*uisdata* is a library for easy data access and manipulation of the datasets offered by the **UNESCO Institute for Statistics** (UIS).

## Library modules
*uisdata.bdds* is the first module developed that lets you download and unpack any dataset archives found on the BDDS repo. You will be able to quickly produce a subset from the national or regional dataset and then merge it to its metadata (e.g. data source) and labels (e.g. indicator names).
- Download and extract a zip dataset archive from the BDDS repository
- Subset the datasets based on lists of countries, years and indicators
- Merge a dataset with its metadata
- Merge a dataset with its country and indicator labels

*uisdata.api* coming in 2022...

## Source code and installation
The source code is currently hosted on PyPi at: xxxxxxxxxx insert pypi repo URL xxxxxxxxxx

## Python requirement
*uisdata* requires a python 64-bit version. 
It has not been tested extensively to find the minimal viable version, but it will work on: 
**python** >=3.6  (64-bit)

## Installation
    pip install uisdata

## Modules Dependencies
*uisdata.bdds* has not been tested extensively to find the minimal viable versions for its dependencies.  
It requires the following libraries:  
**requests** - a standard for making HTTP requests in Python. It abstracts the complexities of making requests behind a simple API.    
**pandas** - an open-source Python Library providing high-performance data manipulation and analysis tool using its powerful data structures.    

## License
MIT License

## Background
Work on *uisdata* started at UIS (UNESCO Institute for Statistics) in 2021 for facilitating programmatic access to the UIS datasets. It is still under active development, and we will be adding features in future iterations.

## Tutorials / use-case
The tutorials will be put in a separate file once other modules are developed.   
*.bdds* Use-case with the SDG dataset archive

    import uisdata.bdds as ud
    
    # Running use-case test
    sdg = ud.bdds("SDG")
    
    sdg_tables = sdg.dataTables()       # create a dict of all the archive data files
    # sdg_readme = sdg.readmeFile()     # save Readme to var
    
    # Options for defining the lists of values for the subset
    
    # Option 1: Get a list of all possible values for the countries, indicators and years using the uniqueVal utility
    allIndic = sdg.uniqueVal(sdg_tables["DATA_NATIONAL"], "INDICATOR_ID")
    allCountry = sdg.uniqueVal(sdg_tables["DATA_NATIONAL"], "COUNTRY_ID")
    allYear = sdg.uniqueVal(sdg_tables["DATA_NATIONAL"], "YEAR")
    allRegion = sdg.uniqueVal(sdg_tables["DATA_REGIONAL"], "REGION_ID")
    allMetadataType = sdg.uniqueVal(sdg_tables["METADATA"], "TYPE")
    
    # Option 2: Get a list of specific values using the searchList utility
    # The utility is hardcoded to search the INDICATOR_IDs in the "LABEL" file
    # Search list for the indicators
    userSearchTerms = ["BULL", "GER", "ADMI", "POV", "5T8"]
    indicListFromSearch = sdg.searchList(sdg_tables, userSearchTerms)
    # Search list for the regions
    userRegionTerms = ['AIMS:', 'ESCAP:']
    regionListFromSearch = sdg.searchList(sdg_tables, userRegionTerms, indic_or_region = "Region")
    
    # Option 3: Custom defined list of values
    # Defining a custom user lists of years, countries, indicators and regions of interest for the subset
    yearSubset = [1998, 2005, 2006, 2008, 2012, 2014, 2015, 2017, 2019]
    countrySubset = ['BLZ', 'CUB', 'AFG', 'LSO', 'ECU']
    indicSubset = ['PRYA.12MO', 'CR.1.URB.F.WPIA', 'GAR.5T8.M', 'NARA.AGM1.Q1.F.LPIA',
                   'TRTP.2T3.GPIA', 'ROFST.2T3.F.CP', 'ROFST.2.GPIA.CP']
    regionSubset = ['SDG: Asia (Central)', 'SDG: Least Developed Countries', 'SDG: Small Island Developing States']
    
    # The following steps will use option 3 to define the use-case subsets
    # Creating a subset of the national dataset
    sdg_CountrySub = sdg.subsetData(sdg_tables["DATA_NATIONAL"], yearSubset, countrySubset, indicSubset)
    
    # Creating a subset of the regional dataset
    sdg_RegionSub = sdg.subsetData(sdg_tables["DATA_REGIONAL"], yearSubset, regionSubset, indicSubset, geoType="Region")
    
    # Adding two types of metadata to the national data subset
    sdg_CountrySub_Meta = sdg.addMetadata(sdg_CountrySub, sdg_tables["METADATA"], metadataType='Source:Data sources')
    sdg_CountrySub_Meta2 = sdg.addMetadata(sdg_CountrySub_Meta, sdg_tables["METADATA"],
                                           metadataType='Under Coverage:Students or individuals')
    
    # Adding country and indicator labels to the national data subset
    sdg_sub_final_1 = sdg.addLabels(sdg_CountrySub_Meta2, sdg_tables["COUNTRY"], keyVariable="COUNTRY_ID")
    sdg_sub_final_2 = sdg.addLabels(sdg_sub_final_1, sdg_tables["LABEL"], keyVariable="INDICATOR_ID")
    
    # The following wrappers allow :
    # A) merge both countries and indicators labels in a single process
    # B) merge any existing metadata to your dataset in a single process
    # C) combines 1 and 2 in a single process
    
    # A) Wrapper for merging all labels
    allLabelMerged = sdg.allLabelMerge(sdg_tables, sdg_tables["DATA_NATIONAL"])
    allLabelMerged_reg = sdg.allLabelMerge(sdg_tables, sdg_tables["DATA_REGIONAL"], geoType="Region")
    
    # B) Wrapper for merging all metadata (only for NATIONAL data)
    allMetaMerged = sdg.allMetaMerge(sdg_tables, sdg_tables["DATA_NATIONAL"])
    
    # C) Wrapper for merging all labels and metadata using the indicator and region lists from option 2
    # National data
    sdgFinalQuick = sdg.allLabelMetaMerge(sdg_tables, yearSubset, countrySubset, indicListFromSearch)
    # Regional data
    sdgFinalQuick_reg = sdg.allLabelMetaMerge(sdg_tables, yearSubset, regionListFromSearch, indicListFromSearch, geoType="Region")
    
