===================
uisdata Module
===================

**Contains functions to select multiple indicators, merge their labels and metadata. It is also a useful way to understand the data structure of the UIS datasets**

XXXX ADD details XXXXXX