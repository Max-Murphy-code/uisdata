from setuptools import setup, find_packages

setup(name='uisdata',

      version='0.1',

      #url='https://github.com/XXXXXX/uisdata',

      #license='MIT',

      author='UIS_DAO',

      author_email='m.murphy@unesco.org',

      description='UIS data select, metadata and label merge',

      packages=find_packages(exclude=['tests']),

      long_description=open('README.md').read(),

      zip_safe=False,

      # test_suite='nose.collector',

      setup_requires=['pandas', 'numpy'])
